#ifndef QUANLYTACGIA_H
#define QUANLYTACGIA_H
#include "header.h"
#include "header.h"
#include "sach.h"
#include "tacgia.h"
#include "donhang.h"
#include "khachhang.h"
#include "trangthaidonhang.h"

class QuanLyTacGia{
    public: 
        virtual void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia) = 0;
        virtual ~QuanLyTacGia(){}
};

class ThemTacGia : public QuanLyTacGia{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};

class XoaTacGia : public QuanLyTacGia{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};

class ChinhSuaTacGia : public QuanLyTacGia{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};

class TacGiaRemoteControl{
    QuanLyTacGia *caulenh; 
    public: 
    void setCommand(QuanLyTacGia* caulenh);
    void pressButton(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};
#endif
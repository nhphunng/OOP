#include "nguoidung.h"

NguoiDungProxy::NguoiDungProxy(string vaiTro){
    realUser = NULL; 
    this->vaiTro = vaiTro; 
}

NguoiDungProxy::~NguoiDungProxy(){
    delete this->realUser; 
}
void QuanTriVien::xulyFile(HeThongQuanLy *nhaSachOO){
    nhaSachOO->xulyFile();
}
void NguoiDungThongThuong::xulyFile(HeThongQuanLy *nhaSachOO){
    return; 
}
void NguoiDungProxy::xulyFile(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->xulyFile(nhaSachOO);
}
void QuanTriVien::quanLyDonHang(HeThongQuanLy *nhaSachOO){
    nhaSachOO->quanLyDonHang();
}
void NguoiDungThongThuong::quanLyDonHang(HeThongQuanLy *nhaSachOO){
    return; 
}
void NguoiDungProxy::quanLyDonHang(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->quanLyDonHang(nhaSachOO);
}
void QuanTriVien::quanLySach(HeThongQuanLy *nhaSachOO){
    nhaSachOO->quanLySach();
}
void NguoiDungThongThuong::quanLySach(HeThongQuanLy *nhaSachOO){
    return; 
}
void NguoiDungProxy::quanLySach(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->quanLySach(nhaSachOO);
}
void QuanTriVien::quanLyTacGia(HeThongQuanLy *nhaSachOO){
    nhaSachOO->quanLyTacGia();
}
void NguoiDungThongThuong::quanLyTacGia(HeThongQuanLy *nhaSachOO){
    return; 
}
void NguoiDungProxy::quanLyTacGia(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->quanLyTacGia(nhaSachOO);
}
void QuanTriVien::thongKeDoanhThu(HeThongQuanLy *nhaSachOO, string ngayThongKe){
    nhaSachOO->thongKeDoanhThu(ngayThongKe);
}
void NguoiDungThongThuong::thongKeDoanhThu(HeThongQuanLy *nhaSachOO, string ngayThongKe){
    return; 
}
void NguoiDungProxy::thongKeDoanhThu(HeThongQuanLy *nhaSachOO,string ngayThongKe){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->thongKeDoanhThu(nhaSachOO, ngayThongKe);
}
void QuanTriVien::thongKeSoLuongSach(HeThongQuanLy *nhaSachOO){
    nhaSachOO->thongKeSoLuongSach();
}
void NguoiDungThongThuong::thongKeSoLuongSach(HeThongQuanLy *nhaSachOO){
    return; 
}
void NguoiDungProxy::thongKeSoLuongSach(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->thongKeSoLuongSach(nhaSachOO);
}
void QuanTriVien::thongKeSoLuongKhachHang(HeThongQuanLy *nhaSachOO){
    nhaSachOO->thongKeSoLuongKhachHang();
}
void NguoiDungThongThuong::thongKeSoLuongKhachHang(HeThongQuanLy *nhaSachOO){
    return; 
}
void NguoiDungProxy::thongKeSoLuongKhachHang(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->thongKeSoLuongKhachHang(nhaSachOO);
}
void QuanTriVien::timKiem(HeThongQuanLy *nhaSachOO){
    return;
}
void NguoiDungThongThuong::timKiem(HeThongQuanLy *nhaSachOO){
    nhaSachOO->timKiem();

}
void NguoiDungProxy::timKiem(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->timKiem(nhaSachOO);
}
void QuanTriVien::xemChiTietSach(HeThongQuanLy *nhaSachOO, string maSach){
    
    return;
}
void NguoiDungThongThuong::xemChiTietSach(HeThongQuanLy *nhaSachOO, string maSach){
    nhaSachOO->xemChiTietSach(maSach);
}
void NguoiDungProxy::xemChiTietSach(HeThongQuanLy *nhaSachOO, string maSach){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->xemChiTietSach(nhaSachOO, maSach);
}
void QuanTriVien::datHang(HeThongQuanLy *nhaSachOO){
    return;
}
void NguoiDungThongThuong::datHang(HeThongQuanLy *nhaSachOO){
    nhaSachOO->datHang();
     
}
void NguoiDungProxy::datHang(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->datHang(nhaSachOO);
}
void QuanTriVien::thanhToan(HeThongQuanLy *nhaSachOO){
    return;
}
void NguoiDungThongThuong::thanhToan(HeThongQuanLy *nhaSachOO){
    nhaSachOO->thanhToan();
    
}
void NguoiDungProxy::thanhToan(HeThongQuanLy *nhaSachOO){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->thanhToan(nhaSachOO);
}
void QuanTriVien::quanLyDonHangDaDat(HeThongQuanLy *nhaSachOO, string maKhachHang){
    return;
}
void NguoiDungThongThuong::quanLyDonHangDaDat(HeThongQuanLy *nhaSachOO, string maKhachHang){
    nhaSachOO->quanLyDonHangDaDat(maKhachHang);
    
}
void NguoiDungProxy::quanLyDonHangDaDat(HeThongQuanLy *nhaSachOO, string maKhachHang){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->quanLyDonHangDaDat(nhaSachOO, maKhachHang);
}
void QuanTriVien::quanLyTaiKhoan(HeThongQuanLy *nhaSachOO, string maKhachHang){
    return;
}
void NguoiDungThongThuong::quanLyTaiKhoan(HeThongQuanLy *nhaSachOO, string maKhachHang){
    nhaSachOO->quanLyTaiKhoan(maKhachHang);
}
void NguoiDungProxy::quanLyTaiKhoan(HeThongQuanLy *nhaSachOO, string maKhachHang){
    if (!realUser) {
        if (this->vaiTro == "Admin") {
            realUser = new QuanTriVien;
        }
        else if (this->vaiTro == "User") {
            realUser = new NguoiDungThongThuong;
        }
        else {
            cout << "Role khong ton tai";
            return;
        }
    }
    realUser->quanLyTaiKhoan(nhaSachOO, maKhachHang);
}



#ifndef NGUOIDUNG_H
#define NGUOIDUNG_H
#include"hethongquanly.h"

class NguoiDung{
    public: 
        virtual ~NguoiDung(){}
        virtual void xulyFile(HeThongQuanLy *nhaSachOO) = 0;
        //2.1
        virtual void quanLySach(HeThongQuanLy *nhaSachOO) = 0;
        virtual void quanLyTacGia(HeThongQuanLy *nhaSachOO) = 0;
        virtual void quanLyDonHang(HeThongQuanLy *nhaSachOO) = 0;
        virtual void thongKeDoanhThu(HeThongQuanLy *nhaSachOO, string ngayThongKe) = 0;
        virtual void thongKeSoLuongSach(HeThongQuanLy *nhaSachOO) = 0;
        virtual void thongKeSoLuongKhachHang(HeThongQuanLy *nhaSachOO) = 0;
        // Nguoi dung thong thuong
        //2.2
        virtual void timKiem(HeThongQuanLy *nhaSachOO) = 0;
        //2.3
        virtual void xemChiTietSach(HeThongQuanLy *nhaSachOO, string maSach) = 0;
        //2.4 
        virtual void datHang(HeThongQuanLy *nhaSachOO) = 0;
        //2.5
        virtual void thanhToan(HeThongQuanLy *nhaSachOO) = 0;
        //2.6
        virtual void quanLyDonHangDaDat(HeThongQuanLy *nhaSachOO, string maKhachHang) = 0;
        //2.7
        virtual void quanLyTaiKhoan(HeThongQuanLy *nhaSachOO, string maKhachHang) = 0;
};

class QuanTriVien: public NguoiDung{
    public:
        void xulyFile(HeThongQuanLy *nhaSachOO);
        //2.1
        void quanLySach(HeThongQuanLy *nhaSachOO);
        void quanLyTacGia(HeThongQuanLy *nhaSachOO);
        void quanLyDonHang(HeThongQuanLy *nhaSachOO);
        void thongKeDoanhThu(HeThongQuanLy *nhaSachOO, string ngayThongKe);
        void thongKeSoLuongSach(HeThongQuanLy *nhaSachOO);
        void thongKeSoLuongKhachHang(HeThongQuanLy *nhaSachOO);
        // Nguoi dung thong thuong
        //2.2
        void timKiem(HeThongQuanLy *nhaSachOO);
        //2.3
        void xemChiTietSach(HeThongQuanLy *nhaSachOO, string maSach);
        //2.4 
        void datHang(HeThongQuanLy *nhaSachOO);
        //2.5
        void thanhToan(HeThongQuanLy *nhaSachOO);
        //2.6
        void quanLyDonHangDaDat(HeThongQuanLy *nhaSachOO, string maKhachHang);
        //2.7
        void quanLyTaiKhoan(HeThongQuanLy *nhaSachOO, string maKhachHang);
};

class NguoiDungThongThuong : public NguoiDung{
    public:
        void xulyFile(HeThongQuanLy *nhaSachOO);
        //2.1
        void quanLySach(HeThongQuanLy *nhaSachOO);
        void quanLyTacGia(HeThongQuanLy *nhaSachOO);
        void quanLyDonHang(HeThongQuanLy* nhaSachOO);
        void thongKeDoanhThu(HeThongQuanLy *nhaSachOO, string ngayThongKe);
        void thongKeSoLuongSach(HeThongQuanLy *nhaSachOO);
        void thongKeSoLuongKhachHang(HeThongQuanLy *nhaSachOO);
        // Nguoi dung thong thuong
        //2.2
        void timKiem(HeThongQuanLy *nhaSachOO);
        //2.3
        void xemChiTietSach(HeThongQuanLy *nhaSachOO, string maSach);
        //2.4 
        void datHang(HeThongQuanLy *nhaSachOO);
        //2.5
        void thanhToan(HeThongQuanLy *nhaSachOO);
        //2.6
        void quanLyDonHangDaDat(HeThongQuanLy *nhaSachOO, string maKhachHang);
        //2.7
        void quanLyTaiKhoan(HeThongQuanLy *nhaSachOO, string maKhachHang);
};

class NguoiDungProxy : public NguoiDung {
    private: 
        NguoiDung *realUser; 
        string vaiTro;
    public:
        NguoiDungProxy(string vaiTro);
        ~NguoiDungProxy();
        void xulyFile(HeThongQuanLy *nhaSachOO);
        //2.1
        void quanLySach(HeThongQuanLy *nhaSachOO);
        void quanLyTacGia(HeThongQuanLy *nhaSachOO);
        void quanLyDonHang(HeThongQuanLy *nhaSachOO);
        void hienThiDSSach(HeThongQuanLy *nhaSachOO);
        void hienThiDSTacGia(HeThongQuanLy *nhaSachOO);
        void hienThiDSKhachHang(HeThongQuanLy *nhaSachOO);
        void hienThiDSDonHang(HeThongQuanLy *nhaSachOO);
        void thongKeDoanhThu(HeThongQuanLy *nhaSachOO, string ngayThongKe);
        void thongKeSoLuongSach(HeThongQuanLy *nhaSachOO);
        void thongKeSoLuongKhachHang(HeThongQuanLy *nhaSachOO);
        // Nguoi dung thong thuong
        //2.2
        void timKiem(HeThongQuanLy *nhaSachOO);
        //2.3
        void xemChiTietSach(HeThongQuanLy *nhaSachOO, string maSach);
        //2.4 
        void datHang(HeThongQuanLy *nhaSachOO);
        //2.5
        void thanhToan(HeThongQuanLy *nhaSachOO);
        //2.6
        void quanLyDonHangDaDat(HeThongQuanLy *nhaSachOO, string maKhachHang);
        //2.7
        void quanLyTaiKhoan(HeThongQuanLy *nhaSachOO, string maKhachHang);

};

#endif
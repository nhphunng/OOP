#ifndef DONHANG_H
#define DONHANG_H
#include "header.h"
#include "sach.h"
#include "trangthaidonhang.h"


class DonHang {
	string maDonHang;
	string ngayDatHang;
	double tongTien;
	TrangThaiDonHang* trangThai;
	vector<pair <Sach*, int> > dsSanPham;
	KhachHang* nguoiMua;
public:
    DonHang();
    DonHang(string maDonHang, string ngayDatHang, double tongTien);
    DonHang(string maDonHang, string ngayDatHang, double tongTien, TrangThaiDonHang* trangThai, vector<pair <Sach*, int> > dsSanPham, KhachHang* nguoiMua);
    DonHang(string maDonHang, string ngayDatHang, double tongTien, string trangThai);
    DonHang(string maDonHang, string ngayDatHang, double tongTien, string trangThai, vector<pair <Sach*, int> > dsSanPham, KhachHang* nguoiMua);
	string getMaDonHang();
	string getNgayDatHang();
	double getTongTien();
	string getTrangThaiDonHang();
	vector<pair <Sach*, int> > getDsSanPham();
	KhachHang* getKhachHang();
	void setMaDonHang(string maDonHangMoi);
	void setNgayDatHang(string ngayDatHangMoi);
	void setTongTien(double tongTienMoi);
	void setTrangThaiDonHang(TrangThaiDonHang* trangThaiMoi);
	void setDsSanPham(vector<pair <Sach*, int> > getDsSanPham);
	void setKhachHang(KhachHang* nguoiMua);
    void hienthiDonHang();
    ~DonHang();
};
#endif

#include "taikhoan.h"

TaiKhoan::TaiKhoan(){
    this->maKhachHang = "";
    matKhau = "";
}
TaiKhoan::TaiKhoan(string maKhachHang, string matkhau){
    this->maKhachHang = maKhachHang; 
    this->matKhau = matkhau;  
}
void TaiKhoan::setMatKhau(string matKhauMoi){
    this->matKhau = matKhauMoi;
}
string TaiKhoan::getMaKhachHang(){
    return maKhachHang; 
}
bool TaiKhoan::dangnhap(){
    string matKhau; 
    cout << "Vui long nhap mat khau: ";
    getline(cin, matKhau);
    if(matKhau == this->matKhau){
        return true; 
    }
    else 
        cout << "Mat khau khong chinh xac \n";
    return false; 
}
TaiKhoan::~TaiKhoan(){
    
}
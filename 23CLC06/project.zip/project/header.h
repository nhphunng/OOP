#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <thread>
#include <chrono>
#include <random>
#include <time.h>
using namespace std;
using namespace this_thread;
using namespace chrono; 

class Sach;
class TacGia; 
class KhachHang; 
class DonHang; 
class TrangThaiDonHang; 
class HeThongQuanLy; 










#include "quanlysach.h" 

void ThemSach::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia) {
    string maSach;
    string tenSach;
    string theLoai;
    string namXuatBan;
    string nhaXuatBan;
    double giaBan;
    int soLuongTonKho;
    string tenTacGia;
    vector<TacGia*> dsTacGiaSachMoi;
    cin.ignore();
    cout << "\nMa sach: "; getline(cin, maSach);
    cout << "Ten sach: "; getline(cin, tenSach);
    cout << "The loai: "; getline(cin, theLoai);
    cout << "Nam xuat ban: "; getline(cin, namXuatBan);
    cout << "Nha xuat ban: "; getline(cin, nhaXuatBan);
    cout << "Gia ban: ";  cin >> giaBan;
    cout << "So luong ton kho: ";  cin >> soLuongTonKho;
    cin.ignore();
    int n = dsTacGia.size();
    do {
        cout << "Nhap ten tac gia nhap 0 de thoat: ";
        getline(cin, tenTacGia);
        if (tenTacGia != "0") {
            bool check = false;
            for (auto& it : dsTacGia) {
                if (it->getHoTen() == tenTacGia) {
                    dsTacGiaSachMoi.push_back(it);
                    check = true;
                    break;
                }
            }
            if (check != true) {
                cout << "Tac gia khong ton tai\n";
            }
        }
    } while (tenTacGia != "0");
    dsSach.push_back(new Sach(maSach, tenSach, theLoai, namXuatBan, nhaXuatBan, giaBan, soLuongTonKho, dsTacGiaSachMoi));
}




void XoaSach::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia){
    string maSachCanXoa; 
    cin.ignore();
    cout << "Nhap ma sach: ";
    getline(cin, maSachCanXoa);
    for(int i = 0; i < dsSach.size(); i++){
        if(maSachCanXoa == dsSach[i]->getMaSach()){
            vector<TacGia*> v = dsSach[i]->getDsTacGia();
            for(auto &it : v){
                vector<Sach*> v2 = it->getdsSach();
                for(int j = 0; j < v2.size(); j++){
                    if(maSachCanXoa == v2[i]->getMaSach()){
                        v2.erase(v2.begin() + i);
                        break; 
                    }
                }
            }
            dsSach.erase(dsSach.begin() + i);
            cout << "Xoa thanh cong \n";
            return; 
        }
    }
    cout << "Xoa khong thanh cong\n";
}

void ChinhSuaSach::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia){
    string maSachCanChinhSua; 
    cout << "Nhap ma sach: ";
    cin.ignore();
    getline(cin, maSachCanChinhSua);
    for(int i = 0; i < dsSach.size(); i++){
        if(maSachCanChinhSua == dsSach[i]->getMaSach()){
            int choice; 
           do{
                cout << "1. Sua ten sach: \n";
                cout << "2. Sua the loai sach: \n";
                cout << "3. Sua nam xuat ban: \n";
                cout << "4. Sua nha xuat ban: \n";
                cout << "5. Sua gia ban \n";
                cout << "6. Sua so luong ton kho\n";
                cout << "0. Thoat chuong trinh\n";
                cin >> choice; 
                cin.ignore();
                if(choice == 1){
                    cout << "Nhap ten sach moi: ";
                    string tenSachMoi; 
                    getline(cin, tenSachMoi);
                    dsSach[i]->setTenSach(tenSachMoi);
                }
                else if(choice == 2){
                    cout << "Nhap the loai sach moi: ";
                    string theLoaiSachMoi; 
                    getline(cin, theLoaiSachMoi);
                    dsSach[i]->setTheLoai(theLoaiSachMoi);
                }
                else if(choice == 3){
                    cout << "Nhap nam xuat ban moi: ";
                    string namXuatBanMoi; 
                    getline(cin, namXuatBanMoi);
                    dsSach[i]->setNamXuatBan(namXuatBanMoi);
                }
                else if(choice == 4){
                    cout << "Nhap nha xuat ban moi: ";
                    string nhaXuatBanMoi; 
                    getline(cin, nhaXuatBanMoi);
                    dsSach[i]->setNhaXuatBan(nhaXuatBanMoi);
                }
                else if(choice == 5){
                    cout << "Nhap gia ban moi: ";
                    double giaBanMoi; 
                    cin >> giaBanMoi; 
                    dsSach[i]->setGiaBan(giaBanMoi);
                }
                else if(choice == 6){
                    cout << "Nhap so luong ton kho: ";
                    int soLuongTonKho; 
                    cin >> soLuongTonKho; 
                    dsSach[i]->setSoLuongTonKho(soLuongTonKho);
                }
                else {
                    cout << "Lua chon khong hop le vui long nhap lai\n";
                }
           }
           while(choice == 0);
           cout << "Sua thanh cong\n";
           return; 
        }
    }
}

void RemoteControl::setCommand(QuanLySach* caulenh){
    this->caulenh = caulenh; 
}

void RemoteControl::pressButton(vector<Sach*> dsSach, vector<TacGia*> dsTacGia){
    if(caulenh){
        caulenh->thucThi(dsSach, dsTacGia);
    }
}


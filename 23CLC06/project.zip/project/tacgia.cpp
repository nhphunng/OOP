#include "tacgia.h"
TacGia::TacGia(){
	maTacGia = "";
	hoTen = "";
}
TacGia::TacGia(string maTacGia, string hoTen, vector<Sach*> dsSach){
	this->maTacGia = maTacGia; 
	this->hoTen = hoTen; 
	this->dsSach = dsSach; 
}
TacGia::TacGia(string maTacGia, string hoTen){
	this->maTacGia = maTacGia; 
	this->hoTen = hoTen; 
}
TacGia::TacGia(string hoTen){
	maTacGia = "";
	this->hoTen = hoTen; 
}
string TacGia::getMaTacGia() {
	return this->maTacGia;
}
string TacGia::getHoTen() {
	return this->hoTen;
}
vector<Sach*> TacGia::getdsSach() {
	return this->dsSach;
}
void TacGia::setMaTacGia(string maTacGiaMoi) {
	this->maTacGia = maTacGiaMoi;
}
void TacGia::setHoTen(string hoTenMoi) {
	this->hoTen = hoTenMoi;
}
void TacGia::setdsSach(vector<Sach*> dsSachMoi) {
	for (auto &it : dsSach) delete it;
	dsSach.clear();
	this->dsSach = dsSachMoi;
}
void TacGia::themSach(Sach* sach){
	dsSach.push_back(sach);
}

void TacGia::hienthiTacGia(){
	cout << this->maTacGia << " ";
	cout << hoTen << " ";
	for(auto it : dsSach){
		it->hienthiSach();
	}
}
TacGia::~TacGia(){
	if(!dsSach.empty())
		for(auto &it : dsSach){
			delete it; 
		}
	dsSach.clear();
}
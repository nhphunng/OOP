#include "hethongquanly.h"

HeThongQuanLy* HeThongQuanLy::getHeThong() {
	if (hethong == NULL)
	{
		hethong = new HeThongQuanLy();
	}
	return hethong;
}

void HeThongQuanLy::delHeThong() {
	if (hethong)
	{
		delete hethong;
		hethong = NULL;
	}
}

HeThongQuanLy::~HeThongQuanLy(){

}

Sach* HeThongQuanLy::tachThongTinSach(string line_info) {
	string maSach, tenSach, theLoai, namXuatBan, nhaXuatBan, danhsachtacgia;
	double giaBan;
	int soLuongTonKho;
	vector<TacGia*> dsTacGiaSach;

	stringstream ss(line_info);
	string tmp;

	getline(ss, maSach, '|');
	getline(ss, tenSach, '|');
	getline(ss, theLoai, '|');
	getline(ss, namXuatBan, '|');
	getline(ss, nhaXuatBan, '|');
	getline(ss, tmp, '|');
	giaBan = stod(tmp);
	getline(ss, tmp, '|');
	soLuongTonKho = stoi(tmp);
	getline(ss, danhsachtacgia);

	stringstream ss1(danhsachtacgia);

	while (getline(ss1, tmp, ',')) {
		//bool check = false; 
		for(int i = 0; i < dsTacGia.size(); i++){
			if(tmp == dsTacGia[i]->getHoTen()){ 
				dsTacGiaSach.push_back(dsTacGia[i]);
				break;
			}
		}
	}
	return new Sach(maSach, tenSach, theLoai, namXuatBan, nhaXuatBan, giaBan, soLuongTonKho, dsTacGiaSach);
}

TacGia* HeThongQuanLy::tachThongTinTacGia(string line_info) {
	string maTacGia, tenTacGia;

	stringstream ss(line_info);

	getline(ss, maTacGia, '|');
	getline(ss, tenTacGia);
	return new TacGia(maTacGia, tenTacGia);
}
KhachHang* HeThongQuanLy::tachThongTinKhachHang(string line_info) {
	string maKhachHang, hoTen, SDT, email, diachi;

	stringstream ss(line_info);

	getline(ss, maKhachHang, '|');
	getline(ss, hoTen, '|');
	getline(ss, SDT, '|');
	getline(ss, email, '|');
	getline(ss, diachi);

	return new KhachHang(maKhachHang, hoTen, SDT, email, diachi);
}
DonHang* HeThongQuanLy::tachThongTinDonHang(string line_info) {
	string maDonHang, ngayDatHang, dsBook, trangThaiDonHang, khachHang;
	double tongTien;
	TrangThaiDonHang* trangThai;
	vector<pair<Sach*, int>> dsSanPham;

	stringstream ss(line_info);
	string tmp;

	getline(ss, maDonHang, '|');
	getline(ss, ngayDatHang, '|');
	getline(ss, tmp, '|');
	tongTien = stod(tmp);
	getline(ss, trangThaiDonHang, '|');
	getline(ss, dsBook, '|');
	getline(ss, khachHang, '\n');


	//Xu ly trang thai don hang
	if (trangThaiDonHang == "DaDat") trangThai = new DaDat();
	else if (trangThaiDonHang == "DaXacNhan") trangThai = new DaXacNhan();
	else if (trangThaiDonHang == "DaThanhToan") trangThai = new DaThanhToan();
	else if (trangThaiDonHang == "DangGiao") trangThai = new DangGiao();
	else if (trangThaiDonHang == "DaGiao") trangThai = new DaGiao();
	else trangThai = new DaHuy();

	//Xu ly sach
	stringstream ss1(dsBook);
	//Do them va them dia chi cua sach vao dsSanPham
	while (getline(ss1, tmp, ',')) {
		stringstream ss2(tmp);
		string tenSach, soLuong;
		int sl;

		getline(ss2, tenSach, '-');
		getline(ss2, soLuong);
		sl = stoi(soLuong);

		for (int i = 0; i < dsSach.size(); i++) {
			if (dsSach[i]->getTenSach() == tenSach) {
				dsSanPham.push_back(make_pair(dsSach[i], sl));
			}
		}
	}
	DonHang* donHangMoi = new DonHang();
	//Xu ly khach hang
	for (int i = 0; i < dsKhachHang.size(); i++) {
		if (dsKhachHang[i]->getHoTen() == khachHang){
			donHangMoi = new DonHang(maDonHang, ngayDatHang, tongTien, trangThai, dsSanPham, dsKhachHang[i]);
			return donHangMoi; 
		}
	}

	// cout << "Khong co khach hang trong ds cua he thong quan li" << endl;
	// dsKhachHang.push_back(new KhachHang(khachHang));
	// DonHang* donHangMoi = new DonHang(maDonHang, ngayDatHang, tongTien, trangThai, dsSanPham, dsKhachHang[dsKhachHang.size() -1]);
	return donHangMoi;
}
TaiKhoan* HeThongQuanLy::tachThongTinTaiKhoan(string line_info){
	string maKhachHang; 
	string matKhau; 
	stringstream ss(line_info);
	getline(ss, maKhachHang,'|');
	getline(ss, matKhau);
	return new TaiKhoan(maKhachHang, matKhau);
}
void HeThongQuanLy::docThongTinSachTuFile(string file_name) {
	ifstream fi;
	fi.open(file_name);

	if (!fi.is_open()) {
		cout << "Loi mo file" << endl;
		exit(1);
	}

	string line_info;
	while (getline(fi, line_info, '\n')) {
		Sach *sachMoi = tachThongTinSach(line_info);
		this->dsSach.push_back(sachMoi);
	}

	fi.close();
}
void HeThongQuanLy::docThongTinTacGiaTuFile(string file_name) {
	ifstream fi;
	fi.open(file_name);

	if (!fi.is_open()) {
		cout << "Loi mo file" << endl;
		exit(1);
	}

	string line_info;
	while (getline(fi, line_info, '\n')) {
		TacGia* tacGiaMoi = tachThongTinTacGia(line_info);
		this->dsTacGia.push_back(tacGiaMoi);
	}

	fi.close();
}

void HeThongQuanLy::docThongTinDonHangTuFile(string file_name) {
	ifstream fi;
	fi.open(file_name);

	if (!fi.is_open()) {
		cout << "Loi mo file" << endl;
		exit(1);
	}

	string line_info;
	while (getline(fi, line_info, '\n')) {
		this->dsDonHang.push_back(tachThongTinDonHang(line_info));
	}

	fi.close();
}
void HeThongQuanLy::docThongTinKhachHangTuFile(string file_name) {
	ifstream fi;
	fi.open(file_name);

	if (!fi.is_open()) {
		cout << "Loi mo file" << endl;
		exit(1);
	}

	string line_info;
	while (getline(fi, line_info, '\n')) {
		this->dsKhachHang.push_back(tachThongTinKhachHang(line_info));
	}

	fi.close();
}
void HeThongQuanLy::docThongTinTaiKhoanTuFile(string file_name){
	ifstream fi;
	fi.open(file_name);

	if (!fi.is_open()) {
		cout << "Loi mo file" << endl;
		exit(1);
	}

	string line_info;
	while (getline(fi, line_info, '\n')) {
		this->dsTaiKhoan.push_back(tachThongTinTaiKhoan(line_info));
	}
	//cout << dsTaiKhoan.size() << endl;
	fi.close();
}
void HeThongQuanLy::xulyFile(){
	string fileNameSach = "sach.txt";
	string fileNameKhachHang  = "khach_hang.txt";
	string fileNameTacGia = "tac_gia.txt";
	string fileNameDonHang = "don_hang.txt";
	string fileNameTaiKhoan = "tai_khoan.txt";
	docThongTinKhachHangTuFile(fileNameKhachHang);
	docThongTinTacGiaTuFile(fileNameTacGia);
	docThongTinSachTuFile(fileNameSach);
	docThongTinDonHangTuFile(fileNameDonHang);
	docThongTinTaiKhoanTuFile(fileNameTaiKhoan);
	for(int i = 0; i < dsSach.size(); i++){
		vector<TacGia*> dsTacGia = dsSach[i]->getDsTacGia();
		for(int j = 0; j < dsTacGia.size(); j++){
			dsTacGia[j]->themSach(dsSach[i]);
		}
	}
}
//2.1
void HeThongQuanLy::quanLySach(){
	RemoteControl remote; 
	while (1) {
		system("cls");
		cout << "\n\t quan-li-sach" << endl;
		cout << "> 1. Them sach\n";
		cout << "> 2. Xoa sach\n";
		cout << "> 3. Chinh sua sach\n";
		cout << "> 4. Quay lai." << endl;
		cout << "Chon (1-4): " << endl;
		int n;
		cin >> n;
		if (n == 1) {
			remote.setCommand(new ThemSach());
			remote.pressButton(dsSach, dsTacGia);
		}
		else if (n == 2) {
			remote.setCommand(new XoaSach());
			remote.pressButton(dsSach, dsTacGia);
		}
		else if( n == 3){
			remote.setCommand(new ChinhSuaSach());
			remote.pressButton(dsSach, dsTacGia);
		}
		else
		{
			return;
		}
	}
}

void HeThongQuanLy::quanLyTacGia(){
	TacGiaRemoteControl remote; 
	while (1) {
		system("cls");
		cout << "\n\t quan-li-tac-gia" << endl;
		cout << "> 1. Them tac gia\n";
		cout << "> 2. Xoa tac gia\n";
		cout << "> 3. Chinh sua tac gia\n";
		cout << "> 4. Quay lai." << endl;
		cout << "Chon (1-4): " << endl;
		int n;
		cin >> n;
		if (n == 1) {
			remote.setCommand(new ThemTacGia());
			remote.pressButton(dsSach, dsTacGia);
		}
		else if (n == 2) {
			remote.setCommand(new XoaTacGia());
			remote.pressButton(dsSach, dsTacGia);
		}
		else if (n == 3) {
			remote.setCommand(new ChinhSuaTacGia());
			remote.pressButton(dsSach, dsTacGia);
		}
		else
		{
			return;
		}
	}
}

void HeThongQuanLy::quanLyDonHang(){
	DonHangRemoteControl remote; 
	while (1) {
		system("cls");
		cout << "\n\t quan-li-don-hang" << endl;
		cout << "> 1. Them don hang\n";
		cout << "> 2. Xoa don hang\n";
		cout << "> 3. Chinh sua don hang\n";
		cout << "> 4. Quay lai." << endl;
		cout << "Chon (1-4): " << endl;
		int n;
		cin >> n;
		if (n == 1) {
			remote.setCauLenh(new ThemDonHang());
			remote.trienKhaiCauLenh(dsSach, dsTacGia, dsDonHang, dsKhachHang);
		}
		else if (n == 2) {
			remote.setCauLenh(new XoaDonHang());
			remote.trienKhaiCauLenh(dsSach, dsTacGia, dsDonHang, dsKhachHang);
		}
		else if (n == 3) {
			remote.setCauLenh(new ChinhSuaDonHang());
			remote.trienKhaiCauLenh(dsSach, dsTacGia, dsDonHang, dsKhachHang);
		}
		else
		{
			return;
		}
	}
}

void HeThongQuanLy::hienThiDSDonHang() {
	cout << "\n> Thong tin cac don hang: " << endl;
	cout << "| Ma don hang\t | Nguoi mua\t    | Trang thai\t| tong tien" << endl;
	cout << "|------------------------------------------------|" << endl;
	for (int i = 0; i < dsDonHang.size(); i++) {
		cout << "| " <<dsDonHang[i]->getMaDonHang() << "| " << dsDonHang[i]->getKhachHang()->getHoTen() << "| " << dsDonHang[i]->getTrangThaiDonHang() << "| " << dsDonHang[i]->getTongTien() << "|" << endl;
	}
}
void HeThongQuanLy::hienThiDSKhachHang() {
	for (size_t i = 0; i < dsKhachHang.size(); ++i) {
		cout << dsKhachHang[i]->getMaKhachHang() << "| " << dsKhachHang[i]->getHoTen() << "| " << dsKhachHang[i]->getSDT() << "| " << dsKhachHang[i]->getEmail() << "| " << dsKhachHang[i]->getDiaChi() << endl;
	}
}
void HeThongQuanLy::hienThiDSSach() {
	for (auto it : this->dsSach) {
		cout << it->getMaSach() << "| " << it->getTheLoai() << "| " << it->getNhaXuatBan() << "| ";
		for (size_t i = 0; i < dsTacGia.size(); ++i) {
			cout << dsTacGia[i]->getHoTen();
			if (i < dsTacGia.size() - 1) cout << " ";
		}
		cout << endl;
	}
}
void HeThongQuanLy::hienThiDSTacGia() {
	for (auto it : this->dsTacGia) {
		cout << it->getMaTacGia() << "| " << it->getHoTen() << "| " ;
		for (size_t i = 0; i < dsSach.size(); ++i) {
			cout << dsSach[i]->getTenSach();
			if (i < dsSach.size() - 1) cout << " ";
		}
		cout << endl;
	}
}

void HeThongQuanLy::thongKeDoanhThu(string ngayThongKe){
	double tongTien = 0; 
	for(auto it : dsDonHang){
		if(ngayThongKe == it->getNgayDatHang()){
			if(it->getTrangThaiDonHang() != "DaHuy")
				tongTien += it->getTongTien();
		}
	}
	cout << "Doanh thu " << ngayThongKe << ": " << tongTien << endl; 
}
void HeThongQuanLy::thongKeSoLuongSach(){
	int count = 0; 
	for(int i = 0; i < dsDonHang.size(); i++)
	{
		vector <pair<Sach*, int> > v =  dsDonHang[i]->getDsSanPham();
		for(auto it : v){
			count += it.second; 
		}
	}
	cout << "So luong sach: " << count; 
}

void HeThongQuanLy::thongKeSoLuongKhachHang(){
	int soLuongKhachHang = 0; 
	for(auto it : dsKhachHang){
		soLuongKhachHang++; 
	}
	cout << "So luong khach hang: " << soLuongKhachHang << endl; 
}
//2.2
void HeThongQuanLy::timKiem() {
	while (1) {
		system("cls");
		cout << "\n\t> tim-kiem-sach";
		cout << "\n> Nhap tieu chi tim kiem:";
		cout << "\n> 1. Ten sach";
		cout << "\n> 2. Tac gia";
		cout << "\n> 3. The loai";
		cout << "\n> 4. Nha xuat ban";
		cout << "\n> 5. Khoang gia";
		cout << "\n> 6. Quay lai";
		cout << "\n Chon (1-6): ";

		int choice;
		cin >> choice;
		cin.ignore();

		switch (choice)
		{
		case 1:
		{
			cout << "\n> Nhap ten sach: ";
			string tenSach;
			getline(cin, tenSach);
			vector<Sach*> dsTimKiem;

			//Tim sach
			for (auto& it : dsSach) {
				if (it->getTenSach() == tenSach) dsTimKiem.push_back(it);
			}
			cout << "\n> Ket qua tim kiem: " << endl;
			cout << "| Ma sach\t | Ten sach\t    | Tac gia\t| Gia ban" << endl;
			cout << "|------------------------------------------------|" << endl;
			for (auto it : dsTimKiem) {
				cout << "| " << it->getMaSach() << "\t| " << it->getTenSach() << "\t\t| ";
				for (auto it1 : it->getDsTacGia()) {
					cout << it1->getHoTen() << ", ";
				}
				cout << "\t| " << it->getGiaBan() << "|" << endl;
			}

			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 2:
		{
			cout << "\n> Nhap ten tac gia: ";
			string tenTacGia;
			getline(cin, tenTacGia);
			vector<Sach*> dsTimKiem;

			//Tim tac gia
			for (auto& it : dsSach) {
				for (auto it1 : it->getDsTacGia())
				{
					if (it1->getHoTen() == tenTacGia) dsTimKiem.push_back(it);
				}
			}
			cout << "\n> Ket qua tim kiem: " << endl;
			cout << "| Ma sach\t | Ten sach\t    | Tac gia\t| Gia ban" << endl;
			cout << "|---------------------------------------------------|" << endl;
			for (auto it : dsTimKiem) {
				cout << "| " << it->getMaSach() << "\t| " << it->getTenSach() << "\t\t| ";
				for (auto it1 : it->getDsTacGia()) {
					cout << it1->getHoTen() << ", ";
				}
				cout << "\t| " << it->getGiaBan() << "|" << endl;
			}
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 3:
		{
			cout << "\n> Nhap ten the loai: ";
			string theLoai;
			getline(cin, theLoai);
			vector<Sach*> dsTimKiem;

			//Tim sach
			for (auto& it : dsSach) {
				if (it->getTheLoai() == theLoai) dsTimKiem.push_back(it);
			}
			cout << "\n> Ket qua tim kiem: " << endl;
			cout << "| Ma sach\t | Ten sach\t    | The loai\t| Gia ban" << endl;
			cout << "|----------------------------------------------------------------|" << endl;
			for (auto it : dsTimKiem) {
				cout << "| " << it->getMaSach() << "\t\t| " << it->getTenSach() << "\t\t| " << it->getTheLoai() << "\t| " << it->getGiaBan() << endl;
			}

			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 4:
		{
			cout << "\n> Nhap te nha xuat ban: ";
			string nhaXuatBan;
			getline(cin, nhaXuatBan);
			vector<Sach*> dsTimKiem;

			//Tim sach
			for (auto& it : dsSach) {
				if (it->getNhaXuatBan() == nhaXuatBan) dsTimKiem.push_back(it);
			}
			cout << "\n> Ket qua tim kiem: " << endl;
			cout << "| Ma sach\t | Ten sach\t    | Nha xuat ban\t| Gia ban" << endl;
			cout << "|----------------------------------------------------------------|" << endl;
			for (auto it : dsTimKiem) {
				cout << "| " << it->getMaSach() << "\t\t| " << it->getTenSach() << "\t\t| " << it->getNhaXuatBan() << "\t| " << it->getGiaBan() << endl;
			}

			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 5:
		{
			cout << "\n> Nhap khoang gia (min-max): ";
			string khoangGia;
			getline(cin, khoangGia);
			stringstream ss(khoangGia);
			float max, min;
			string tmp;
			vector<Sach*> dsTimKiem;

			//Tach thong tin min - max
			getline(ss, tmp, '-');
			min = stof(tmp);
			getline(ss, tmp);
			max = stof(tmp);

			//Tim sach
			for (auto& it : dsSach) {
				if (it->getGiaBan() >= min && it->getGiaBan() <= max) dsTimKiem.push_back(it);
			}
			cout << "\n> Ket qua tim kiem: " << endl;
			cout << "| Ma sach\t | Ten sach\t    | Nha xuat ban\t| Gia ban" << endl;
			cout << "|----------------------------------------------------------------|" << endl;
			for (auto it : dsTimKiem) {
				cout << "| " << it->getMaSach() << "\t\t| " << it->getTenSach() << "\t\t| " << it->getNhaXuatBan() << "\t| " << it->getGiaBan() << endl;
			}

			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		default:
			return;
			break;
		}
	}
}
//2.3
void HeThongQuanLy::xemChiTietSach(string maSach){
	for (auto it : dsSach) {
		if (maSach == it->getMaSach()) {
				it->hienthiSach();
				return;
		}
	}
	cout << "Khong tim thay ma sach tuong ung\n";

}
//2.4 
void HeThongQuanLy::datHang(){
	string maSach; 
	vector<pair< Sach*, int> > dsSachMua;
	double tongTien = 0;  
	string hoTen, SDT, diachi; 
	cout << "> Nhap ho ten nguoi mua: ";
	getline(cin, hoTen);
	cout << "> Nhap SDT: ";
	getline(cin, SDT);
	cout << "> Nhap dia chi: ";
	getline(cin, diachi);
	cout << "\n> Nhap ma sach vaf so luong:" << endl;
	do{
		cout << "> Nhap ma sach, nhap 0 de dung: ";
		getline(cin, maSach);
		if(maSach != "0"){
			for(auto &it : dsSach){
				if(maSach == it->getMaSach()){
					int soluong; 
					cout << "> Nhap so luong sach: ";
					cin >> soluong; cin.ignore();
					if(soluong > it->getSoLuongTonKho()){
						cout << "> So luong sach khong du" << endl; 
						break;
					}
					dsSachMua.push_back(make_pair(it, soluong));
					tongTien += it->getGiaBan()*soluong;
					it->setSoLuongTonKho(it->getSoLuongTonKho() - soluong);
				}
			}
		}
	}while(maSach != "0");
	for(auto it : dsSachMua){
		cout << it.first->getMaSach() << " " << it.first->getTenSach() << " " << it.second << " " << it.first->getGiaBan() << " " << it.first->getGiaBan()*it.second << endl; 
	}
	
	bool check = true; 
	string maDonHang = "";
	do{
		check = true; 
		srand(time(0));
		int randnumber = rand()%100;
		maDonHang = "DH0" + to_string(randnumber);
		for(auto it : dsDonHang){
			if(maDonHang == it->getMaDonHang()){
				check = false; 
				break; 
			}
		}
	}while(check == false);
	dsDonHang.push_back(new DonHang(maDonHang, "15/12/2024", tongTien, "DaDat", dsSachMua, new KhachHang(hoTen, SDT, diachi)));

	cout << "\t> Xac nhan thong tin don hang" << endl;
	cout << "> Ma don hang: " << maDonHang << endl;
	cout << "> Tong tien: " << tongTien << endl;
	cout << "> Xac nhan thong tin dong hang:\n";
	cout << "> Ho ten: " << hoTen << endl;
	cout << "> SDT: " << SDT << endl;
	cout << "> Dia chi: " << diachi << endl;
}
//2.5
void HeThongQuanLy::thanhToan(){
	hienThiDSDonHang();
	string maDonHang;
	DonHang* target = new DonHang();
	int check = 0;
	cout << "\n\t> Nhap ma don hang can thanh toan: ";
	getline(cin, maDonHang);

	cout << "\n\t> thanh-toan-don-hang " << maDonHang << endl;

	for (auto it : dsDonHang) {
		if (it->getMaDonHang() == maDonHang) {
			target = it;
			check = 1;
		}
	}
	//Xu ly don hang khong ton tai
	if (check == 0) {
		cout << "Don hang khong ton tai. Vui long kiem tra lai.\n";
		return;
	}

tt1:
	target->hienthiDonHang(); 
	//Xu ly hien thi thong tin don hang duoc chon...

	cout << "\n> Chon phuong thuc thanh toan:\n";
	cout << "> 1. The tin dung/ ghi no\n";
	cout << "> 2. Chuyen khoan ngan hang\n";
	cout << "> 3. Vi dien tu (Momo, Zalopay, ...)\n";
	cout << "> 4. Thanh toan khi nhan hang (COD)\n";
	cout << "Chon (1-4): ";
	int choice;
	cin >> choice;
	cout << endl;
	ThanhToan* thanhToan = NULL;
	switch (choice)
	{
	case 1:
	{
		thanhToan = new TheTinDung();
		break;
	}
	case 2:
	{
		thanhToan = new ChuyenKhoan();
		break;
	}
	case 3:
	{
		int choose;
		cout << "\n> Chon vi dien tu: ";
		cout << "\n> 1. Momo ";
		cout << "\n> 2. Vnpay ";
		cout << "Chon (1-2): ";
		cin >> choose;
		if (choose == 1 || choose == 2) thanhToan = new ViDienTu();
		else {
			cout << "Ten vi dien tu khong ton tai\n";
			goto tt1;
		}
		break;
	}
	case 4:
	{
		thanhToan = new COD();
		break;
	}
	default:
		cout << "Lua chon khong hop le.\n";
		cout << "Ban co muon lua chon lai? (1: yes/0: no)";
		int tmp;
		cin >> tmp;
		if (tmp == 1) goto tt1;
		else break;
	}

	BoiCanhThanhToan context(thanhToan);
	if (choice != 4 && context.xuLyThanhToan(target->getTongTien())) {
		if (target->getTrangThaiDonHang() != "DaHuy" && target->getTrangThaiDonHang() != "DaThanhToan") {
				target->setTrangThaiDonHang(new DaThanhToan());
				
				cout << "\n> Doi xac nhan thanh toan ...";
				sleep_for(seconds(2));
				cout << "\n\n> Thanh toan " << maDonHang << " thanh cong!";
				cout << "\n> Ve cua ban da duoc cap nhat trang thai \"Da thanh toan.\"";
				cout << "\n> Vui long kiem tra email de xem thong tin xac nhan.";

				
				string Enter;
				getline(cin, Enter);
		}
		else {
				cout << "\n> Thanh toan " << maDonHang << " that bai do ve da thanh toan hoac da huy!\n";
				
				string Enter;
				getline(cin, Enter);
				
		}
	} 
	else if (context.xuLyThanhToan(target->getTongTien()) && choice == 4) {
		if (target->getTrangThaiDonHang() != "DaHuy" && target->getTrangThaiDonHang() != "DaThanhToan") {
			target->setTrangThaiDonHang(new DaXacNhan());
			
			cout << "\n> Doi xac nhan thanh toan ..." << endl;
			sleep_for(seconds(2));
			cout << "\n> Vui long thanh toan don hang " << maDonHang << " khi nhan hang";
			cout << "\n> Ve cua ban da duoc cap nhat trang thai \"Da xac nhan.\"";
			cout << "\n> Vui long kiem tra email de xem thong tin xac nhan.";

			
			string Enter;
			getline(cin, Enter);
		}
		else {
			cout << "\n> Thanh toan " << maDonHang << " that bai do ve da thanh toan hoac da huy!\n";

			
			string Enter;
			getline(cin, Enter);
		}
	}
	else {
		cout << "Thanh toan that bai. Vui long thu lai\n";
		system("cls");
		goto tt1;
	}
}
//2.6
void HeThongQuanLy::quanLyDonHangDaDat(string maKhachHang){
	for(int i = 0; i < dsDonHang.size(); i++){
		if(maKhachHang == dsDonHang[i]->getKhachHang()->getMaKhachHang()){
			dsDonHang[i]->hienthiDonHang();
		}
	}
	cout << "Chon ma don hang de xem chi tiet hoac huy: "; 
	string maDonHangCanHuy; 
	getline(cin, maDonHangCanHuy);
	cout << "Chi tiet dong hang " << maDonHangCanHuy << endl; 
	DonHang* donHangCanChinhSua = NULL; 
	for(int i = 0; i < dsDonHang.size(); i++){
		if(maDonHangCanHuy == dsDonHang[i]->getMaDonHang()){
			dsDonHang[i]->hienthiDonHang();
			donHangCanChinhSua = dsDonHang[i];
			break; 
		}
	}
	cout << "Chon thao tac:\n";
	cout << "1. Huy don hang:";
	cout << "2. Quay lai:";
	int n; 
	cin >> n; 
	if(n == 1){
		if(donHangCanChinhSua != NULL){
			donHangCanChinhSua->setTrangThaiDonHang(new DaHuy);
			cout << "Don hang " << maDonHangCanHuy << " da duoc huy\n";
		}
	}
	else if(n == 2)
	{
		return; 
	}
}
//2.7
void HeThongQuanLy::quanLyTaiKhoan(string maKhacHang){ 
	while (1) {
	system("cls");
		for (int i = 0; i < dsTaiKhoan.size(); i++) {
			cout << dsTaiKhoan[i]->getMaKhachHang() << endl;
			if (maKhacHang == dsTaiKhoan[i]->getMaKhachHang()) {
				bool check = dsTaiKhoan[i]->dangnhap();
				cout << "\n> Chon thao tac: \n";
				cout << "> 1. Chinh sua thong tin: \n";
				cout << "> 2. Thay doi mat khau: \n";
				cout << "> 3. Quay lai: \n";
				cout << "Chon (1-3): ";
				int n;
				cin >> n;
				cin.ignore();
				if (n == 1) {
					string hoTen, SDT, email, diachi;
					cout << "Ho ten: ";
					getline(cin, hoTen);
					cout << "SDT: ";
					getline(cin, SDT);
					cout << "Email: ";
					getline(cin, email);
					cout << "Dia chi: ";
					getline(cin, diachi);
					for (int i = 0; i < dsKhachHang.size(); i++) {
						if (dsKhachHang[i]->getMaKhachHang() == maKhacHang) {
							dsKhachHang[i]->setHoTen(hoTen);
							dsKhachHang[i]->setSDT(SDT);
							dsKhachHang[i]->setEmail(email);
							dsKhachHang[i]->setDiaChi(diachi);
						}
					}

					cout << ">Chinh sua thong tin thanh cong\n";
					cout << "\n> Nhan Enter de tiep tuc.";
					string Enter;
					getline(cin, Enter);
					break;
				}
				else if (n == 2) {
					string matKhauMoi;
					getline(cin, matKhauMoi);
					for (int i = 0; i < dsTaiKhoan.size(); i++) {
						if (maKhacHang == dsTaiKhoan[i]->getMaKhachHang()) {
							dsTaiKhoan[i]->setMatKhau(matKhauMoi);

						}
					}
					cout << "\n> Nhan Enter de tiep tuc.";
					string Enter;
					getline(cin, Enter);
					break;
				}
				else
				{
					return;
				}
			}
		}
	}
	
}
#include "donhang.h"

DonHang::DonHang(){
	maDonHang = "";
	ngayDatHang = "";
	tongTien = 0; 
	trangThai = new DaDat; 
}
DonHang::DonHang(string maDonHang, string ngayDatHang, double tongTien){
	this->maDonHang = maDonHang; 
	this->ngayDatHang = ngayDatHang; 
	this->tongTien = tongTien; 
}
DonHang::DonHang(string maDonHang, string ngayDatHang, double tongTien, TrangThaiDonHang* trangThai, vector<pair <Sach*, int> > dsSanPham, KhachHang* nguoiMua){
	this->maDonHang = maDonHang; 
	this->ngayDatHang = ngayDatHang; 
	this->tongTien = tongTien; 
	this->trangThai = trangThai; 
	this->dsSanPham = dsSanPham; 
	this->nguoiMua = nguoiMua; 
}
DonHang::DonHang(string maDonHang, string ngayDatHang, double tongTien, string trangThai){
	this->maDonHang = maDonHang; 
	this->ngayDatHang = ngayDatHang; 
	this->tongTien = tongTien; 
	if(trangThai == "DaDat") this->setTrangThaiDonHang(new DaDat);
	else if (trangThai == "DaXacNhan") this->setTrangThaiDonHang(new DaXacNhan);
	else if (trangThai == "DaThanhToan") this->setTrangThaiDonHang(new DaThanhToan);
	else if (trangThai == "DangGiao") this->setTrangThaiDonHang(new DangGiao);
	else if (trangThai == "DaGiao") this->setTrangThaiDonHang(new DaGiao);
	else this->setTrangThaiDonHang(new DaHuy);
}
DonHang::DonHang(string maDonHang, string ngayDatHang, double tongTien, string trangThai, vector<pair <Sach*, int> > dsSanPham, KhachHang* nguoiMua){
	this->maDonHang = maDonHang; 
	this->ngayDatHang = ngayDatHang; 
	this->tongTien = tongTien; 
	if(trangThai == "DaDat") this->setTrangThaiDonHang(new DaDat);
	else if (trangThai == "DaXacNhan") this->setTrangThaiDonHang(new DaXacNhan);
	else if (trangThai == "DaThanhToan") this->setTrangThaiDonHang(new DaThanhToan);
	else if (trangThai == "DangGiao") this->setTrangThaiDonHang(new DangGiao);
	else if (trangThai == "DaGiao") this->setTrangThaiDonHang(new DaGiao);
	else this->setTrangThaiDonHang(new DaHuy);
	this->dsSanPham = dsSanPham; 
	this->nguoiMua = nguoiMua; 
}

string DonHang::getMaDonHang() {
	return this->maDonHang;
}
string DonHang::getNgayDatHang() {
	return this->ngayDatHang;
}
double DonHang::getTongTien() {
	return this->tongTien;
}
string DonHang::getTrangThaiDonHang() {
	return this->trangThai->layTrangThai();
}
vector<pair <Sach*, int> > DonHang::getDsSanPham() {
	return this->dsSanPham;
}
KhachHang* DonHang::getKhachHang() {
	return this->nguoiMua;
}
void DonHang::setMaDonHang(string maDonHangMoi) {
	this->maDonHang = maDonHangMoi;
}
void DonHang::setNgayDatHang(string ngayDatHangMoi) {
	this->ngayDatHang = ngayDatHangMoi;
}
void DonHang::setTongTien(double tongTienMoi) {
	this->tongTien = tongTienMoi;
}
void DonHang::setTrangThaiDonHang(TrangThaiDonHang* trangThaiMoi) {
	delete this->trangThai;
	this->trangThai = trangThaiMoi;
}
void DonHang::setDsSanPham(vector<pair <Sach*, int> > dsSanPhamMoi) {
	for (auto &it : dsSanPham) delete it.first;
	dsSanPham.clear();
	this->dsSanPham = dsSanPhamMoi;
}
void DonHang::setKhachHang(KhachHang* nguoiMuaMoi) {
	//delete this->nguoiMua;
	this->nguoiMua = nguoiMuaMoi;
}
void DonHang::hienthiDonHang(){
	cout << maDonHang << " "; 
	cout << ngayDatHang << " ";
	for(int i = 0; i < this->dsSanPham.size(); i++){
		dsSanPham[i].first->hienthiSach(); 
	}
	cout << tongTien << " ";
	cout << trangThai->layTrangThai() << " " << endl;
}
DonHang::~DonHang(){
	delete trangThai; 
	if(!dsSanPham.empty())
		for(auto &it : dsSanPham){
			delete it.first; 
		}
	dsSanPham.clear();
	//delete nguoiMua; 
}
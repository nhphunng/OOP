#include "trangthaidonhang.h"


string DaDat::layTrangThai() {
    return "DaDat";
}
string DaXacNhan::layTrangThai() {
    return "DaXacNhan";
}
string DaThanhToan::layTrangThai() {
    return "DaThanhToan";
}
string DangGiao::layTrangThai() {
    return "DangGiao";
}
string DaGiao::layTrangThai() {
    return "DaGiao";
}
string DaHuy::layTrangThai() {
    return "DaHuy";
}
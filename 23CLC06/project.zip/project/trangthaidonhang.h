#ifndef TRANGTHAIDONHANG_H
#define TRANGTHAIDONHANG_H
#include "header.h"
class TrangThaiDonHang {
public:
	virtual string layTrangThai() = 0;
	virtual ~TrangThaiDonHang() {};
};

class DaDat : public TrangThaiDonHang {
public:
	string layTrangThai();
	~DaDat() {}
};

class DaXacNhan : public TrangThaiDonHang {
public:
	string layTrangThai();
	~DaXacNhan() {}
};

class DaThanhToan : public TrangThaiDonHang {
public:
	string layTrangThai();
	~DaThanhToan() {}
};

class DangGiao : public TrangThaiDonHang {
public:
	string layTrangThai();
	~DangGiao() {}
};

class DaGiao : public TrangThaiDonHang {
public:
	string layTrangThai();
	~DaGiao() {}
};

class DaHuy : public TrangThaiDonHang {
public:
	string layTrangThai();
	~DaHuy() {}
};

#endif

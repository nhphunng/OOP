#include "khachhang.h"

KhachHang::KhachHang(){
	maKhachHang ="";
	hoTen = "";
	SDT = "";
	email = "";
}
KhachHang::KhachHang(string maKhachHang, string hoTen, string SDT, string email, string diachi){
	this->maKhachHang = maKhachHang; 
	this->hoTen = hoTen; 
	this->SDT = SDT;
	this->email = email; 
	this->diachi = diachi; 
}
KhachHang::KhachHang(string hoTen, string SDT, string diachi){
	maKhachHang = "";
	this->hoTen = hoTen; 
	this->SDT = SDT; 
	this->diachi = diachi; 
	this->email = "";
	SDT = "";
	email = "";
}
KhachHang::KhachHang(string hoTen){
	maKhachHang = "";
	this->hoTen = hoTen; 
}
string KhachHang::getMaKhachHang() {
	return this->maKhachHang;
}
string KhachHang::getHoTen() {
	return this->hoTen;
}
string KhachHang::getSDT() {
	return this->SDT;
}
string KhachHang::getEmail() {
	return this->email;
}
string KhachHang::getDiaChi(){
	return this->diachi; 
}
void KhachHang::setMaKhachHang(string maKhachHangMoi) {
	this->maKhachHang = maKhachHangMoi;
}
void KhachHang::setHoTen(string hoTenMoi) {
	this->hoTen = hoTenMoi;
}
void KhachHang::setSDT(string SDTmoi) {
	this->SDT = SDTmoi;
}
void KhachHang::setEmail(string emailMoi) {
	this->email = emailMoi;
}
void KhachHang::setDiaChi(string diaChiMoi){
	this->diachi = diaChiMoi;
}
void KhachHang::hienThiKhachHang(){
	cout << this->maKhachHang << " ";
	cout << this->hoTen << " ";
	cout << this->SDT << " ";
	cout << this->email << " ";
	cout << this->diachi << endl; 
}
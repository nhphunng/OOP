#ifndef KHACHHANG_H
#define KHACHHANG_H
#include "header.h"

class KhachHang {
	string maKhachHang;
	string hoTen;
	string SDT;
	string email;
	string diachi; 
public:
    KhachHang();
    KhachHang(string maKhachHang, string hoTen, string SDT, string email, string diachi);
	KhachHang(string hoTen, string SDT, string diachi);
	KhachHang(string hoTen);
	string getMaKhachHang();
	string getHoTen();
	string getSDT();
	string getEmail();
	string getDiaChi(); 
	void setMaKhachHang(string maKhachHangMoi);
	void setHoTen(string hoTenMoi);
	void setSDT(string SDTmoi);
	void setEmail(string emailMoi);
	void setDiaChi(string diaChiMoi);
    void hienThiKhachHang();
	~KhachHang(){};
};


#endif
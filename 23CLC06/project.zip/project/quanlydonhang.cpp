#include "quanlydonhang.h"

// void ThemDonHang::thucThi(vector<Sach> &dsSach, vector<TacGia> &dsTacGia, vector<DonHang> &dsDonHang,vector<KhachHang*> dsKhachHang){
//     string maDonHang;
// 	string ngayDatHang;
// 	double tongTien = 0;
// 	string trangThai;
//     string tenSach; 
//     string tenNguoiMua; 
// 	vector<pair<Sach*, int> > dsSanPham;
// 	KhachHang* nguoiMua = NULL;
//     cin.ignore();
//     getline(cin, maDonHang);
//     getline(cin, tenNguoiMua);
//     getline(cin, ngayDatHang);
//     getline(cin, trangThai);
//     do{
//         //cin.ignore();
//         cout << "Nhap ten sach nhap 0 de thoat: ";
//         getline(cin, tenSach);
//         for(auto &it : dsSach){
//             if(tenSach == it.getTenSach()){
//                 cout << "Them so luong sach: ";
//                 int soluong; 
//                 cin >> soluong; 
//                 cin.ignore();
//                 dsSanPham.push_back(make_pair(&it, soluong));
//                 tongTien += it.getGiaBan()*soluong; 
//             }
//         }
//     }
//     while(tenSach != "0");
//     for(auto &it : dsKhachHang){
//         if(tenNguoiMua == it.getHoTen()){
//             nguoiMua = &it;
//             DonHang donHangMoi =  DonHang(maDonHang, ngayDatHang, tongTien, trangThai, dsSanPham, nguoiMua);
//             dsDonHang.push_back(donHangMoi);
//             cout << "Them don hang thanh cong\n";
//             return; 
//         }
//     }
//     string maKhachHang; 
//     string SDT; 
//     string email; 
//     string diaChi; 
//     cout << "Day la khach hang moi \n";
//     cout << "Nhap ma khach hang: ";
//     getline(cin, maKhachHang);
//     cout << "Nhap so dien thoai: ";
//     getline(cin, SDT);
//     cout << "Nhap email: ";
//     getline(cin, email);
//     cout << "Nhap dia chi: ";
//     getline(cin, diaChi);
//     KhachHang khachhang = KhachHang(maKhachHang, tenNguoiMua, SDT, email, diaChi);
//     cout << "Taokhachhangthanhcong\n";
//     dsKhachHang.push_back(khachhang);
//     DonHang donHangMoi = DonHang(maDonHang, ngayDatHang, tongTien, trangThai, dsSanPham, &dsKhachHang.back());
//     dsDonHang.push_back(donHangMoi);
//     donHangMoi.hienthiDonHang();
//     cout << "Them don hang thanh cong\n";
// }
void ThemDonHang::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang) {
    string maDonHang, ngayDatHang, trangThai, tenSach, tenNguoiMua;
    double tongTien = 0;
    vector<pair<Sach*, int>> dsSanPham;
    KhachHang* nguoiMua = nullptr;

    cin.ignore();
    cout << "Nhap ma don hang: ";
    getline(cin, maDonHang);

    cout << "Nhap ten nguoi mua: ";
    getline(cin, tenNguoiMua);

    cout << "Nhap ngay dat hang: ";
    getline(cin, ngayDatHang);

    cout << "Nhap trang thai don hang: ";
    getline(cin, trangThai);

    do {
        cout << "Nhap ten sach (nhap 0 de thoat): ";
        getline(cin, tenSach);

        if (tenSach == "0") break;

        bool sachTimThay = false;
        for (auto &it : dsSach) {
            if (tenSach == it->getTenSach()) {
                sachTimThay = true;

                cout << "Them so luong sach: ";
                int soluong;
                cin >> soluong;
                cin.ignore(); 
                if(soluong < it->getSoLuongTonKho()){
                    dsSanPham.push_back(make_pair(it, soluong));
                    tongTien += it->getGiaBan() * soluong;
                    it->setSoLuongTonKho(it->getSoLuongTonKho() - soluong);
                    cout << "Da them " << soluong << " cuon sach '" << tenSach << "'\n";
                    break;
                }
                cout << "So luong sach khong du\n";
                break;
            }
        }

        if (!sachTimThay) {
            cout << "Sach '" << tenSach << "' khong ton tai trong danh sach!\n";
        }
    } while (tenSach != "0");

    if(dsSanPham.empty()){
        cout << "Don hang phai co san pham \n";
        return; 
    }

    for (auto &it : dsKhachHang) {
        if (tenNguoiMua == it->getHoTen()) {
            nguoiMua = it;

            dsDonHang.push_back(new DonHang(maDonHang, ngayDatHang, tongTien, trangThai, dsSanPham, nguoiMua));

            cout << "Them don hang thanh cong!\n";
            return;
        }
    }

    // Nếu khách hàng mới, yêu cầu nhập thông tin
    string maKhachHang, SDT, email, diaChi;
    cout << "Day la khach hang moi.\n";
    cout << "Nhap ma khach hang: ";
    getline(cin, maKhachHang);

    cout << "Nhap so dien thoai: ";
    getline(cin, SDT);

    cout << "Nhap email: ";
    getline(cin, email);

    cout << "Nhap dia chi: ";
    getline(cin, diaChi);

    // Tạo khách hàng mới và thêm vào danh sách
    dsKhachHang.push_back(new KhachHang(maKhachHang, tenNguoiMua, SDT, email, diaChi));
    nguoiMua = dsKhachHang.back(); // Lấy con trỏ sau khi đã thêm


    cout << "Tao khach hang thanh cong!\n";

    // Tạo đơn hàng mới
    dsDonHang.push_back(new DonHang(maDonHang, ngayDatHang, tongTien, trangThai, dsSanPham, nguoiMua));
    cout << "Them don hang thanh cong!\n";
}

void XoaDonHang::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang){
    cout << "Nhap ma don hang can xoa: ";
    string maDonHangCanXoa; 
    cin.ignore();
    getline(cin, maDonHangCanXoa);
    for(int i = 0; i < dsDonHang.size(); i++){
        if(maDonHangCanXoa == dsDonHang[i]->getMaDonHang()){
            dsDonHang.erase(dsDonHang.begin() + i);
            cout << "Xoa don hanh thanh cong\n";
            return; 
        }
    }
    cout << "Khong tim thay ma don hang \n";
}

void ChinhSuaDonHang::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang){
    cout << "Nhap ma don hang can chinh sua: ";
    string maDonHang; 
    cin.ignore();
    getline(cin, maDonHang);
    for(auto &it : dsDonHang){
        if(maDonHang == it->getMaDonHang()){
            cout << "Chinh sua trang thai don hang: \n";
            cout << "1. DaDat \n";
            cout << "2. DaXacNhan\n";
            cout << "3. DaThanhToan\n";
            cout << "4. DangGiao\n";
            cout << "5. DaGiao\n";
            cout << "6. DaHuy\n";
            int choice; 
            cin >> choice; 
            if(choice == 1){
                it->setTrangThaiDonHang(new DaDat);
            }
            else if(choice == 2){
                it->setTrangThaiDonHang(new DaXacNhan);
            }
            else if(choice == 3){
                it->setTrangThaiDonHang(new DaThanhToan);
            }
            else if(choice == 4){
                it->setTrangThaiDonHang(new DangGiao);
            }
            else if(choice == 5){
                it->setTrangThaiDonHang(new DaGiao);
            }
            else if(choice == 6){
                it->setTrangThaiDonHang(new DaHuy);
            }
            cout << "Chinh sua don hang thanh cong\n";
            return; 
        }
    }
    cout << "Khong tim thay ma don hang\n";
}

void DonHangRemoteControl::setCauLenh(QuanLyDonHang* caulenh){
    this->caulenh = caulenh; 
}

void DonHangRemoteControl::trienKhaiCauLenh(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang){
    if(caulenh){
        caulenh->thucThi(dsSach, dsTacGia, dsDonHang, dsKhachHang);
    }
}
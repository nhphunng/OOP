#ifndef TACGIA_H
#define TACGIA_H
#include "header.h"
#include "sach.h"

class TacGia {
	string maTacGia;
	string hoTen;
	vector<Sach*> dsSach;
public:
    TacGia();
	TacGia(string maTacGia, string hoTen, vector<Sach*> dsSach);
    TacGia(string hoTen);
	TacGia(string maTacGia,string hoTen);
	string getMaTacGia();
	string getHoTen();
	vector<Sach*> getdsSach();
	void setMaTacGia(string maTacGiaMoi);
	void setHoTen(string hoTenMoi);
	void setdsSach(vector<Sach*> dsSachMoi);
    void themSach(Sach* sach);
    void hienthiTacGia();
	~TacGia();
};

#endif

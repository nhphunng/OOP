#ifndef SACH_H
#define SACH_H
#include "header.h"
#include "tacgia.h"

class Sach {
	string maSach;
	string tenSach;
	string theLoai;
	string namXuatBan;
	string nhaXuatBan;
	double giaBan;
	int soLuongTonKho;
	vector<TacGia*> dsTacGia;
public:
    Sach();
    Sach(string tenSach);
    Sach(string maSach, string tenSach, string theLoai, string namXuatBan, string nhaXuatBan, double giaBan, int soLuongTonKho, vector<TacGia*> dsTacGia);
	Sach(const Sach &other);
	string getMaSach();
	string getTenSach();
	string getTheLoai();
	string getNamXuatBan();
	string getNhaXuatBan();
	double getGiaBan();
	int getSoLuongTonKho();
	vector<TacGia*> getDsTacGia();
	void setMaSach(string maSachMoi);
	void setTenSach(string tenSachMoi);
	void setTheLoai(string theLoaiMoi);
	void setNamXuatBan(string namXuatBanMoi);
	void setNhaXuatBan(string nhaXuatBanMoi);
	void setGiaBan(double giaBanMoi);
	void setSoLuongTonKho(int soLuongTonKhoMoi);
	void setDsTacGia(vector<TacGia*> dsTacGiaMoi);
    virtual void hienthiSach();
	void themTacGia(TacGia* tacgia);
	~Sach();
};
class SachCoMoTa : public Sach{
	private:
		string moTa; 
	public: 
		SachCoMoTa(string maSach, string tenSach, string theLoai, string namXuatBan, string nhaXuatBan, double giaBan, int soLuongTonKho, vector<TacGia*> dsTacGia, string mota);
		void hienthiSach();
};
#endif
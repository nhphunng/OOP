#ifndef QUANLYDONHANG_H
#define QUANLYDONHANG_H
#include "header.h"
#include "sach.h"
#include "tacgia.h"
#include "donhang.h"
#include "khachhang.h"
#include "trangthaidonhang.h"

class QuanLyDonHang{
    public: 
        virtual void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang) = 0;
        virtual ~QuanLyDonHang(){}
};

class ThemDonHang : public QuanLyDonHang{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang);
};

class XoaDonHang : public QuanLyDonHang{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang);
};

class ChinhSuaDonHang : public QuanLyDonHang{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang);
};

class DonHangRemoteControl{
    QuanLyDonHang *caulenh; 
    public: 
    void setCauLenh(QuanLyDonHang* caulenh);
    void trienKhaiCauLenh(vector<Sach*> dsSach, vector<TacGia*> dsTacGia, vector<DonHang*> dsDonHang, vector<KhachHang*> dsKhachHang);
};

#endif
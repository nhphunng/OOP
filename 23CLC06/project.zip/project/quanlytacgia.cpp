#include "quanlytacgia.h"

void ThemTacGia::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia){
    string maTacGia; 
    string hoTen; 
    string tenSach;  
    vector<Sach*> dsSachMoi; 
    cin.ignore();
    getline(cin, maTacGia);
    getline(cin, hoTen);
    //cin.ignore();
    int n = dsSach.size();
    do{
        cout << "Nhap ten sach nhap 0 de thoat: ";
        getline(cin, tenSach);
        if(tenSach != "0"){
            bool check = false; 
            for(auto &it : dsSach){
                if(it->getTenSach() == tenSach){
                    dsSachMoi.push_back(it);
                    check = true; 
                    break; 
                }
            }
            if(check == false){
                Sach *sachMoi = new Sach(tenSach);
                dsSach.push_back(sachMoi);
                dsSachMoi.push_back(dsSach[dsSach.size() - 1]);
            }
        }
    }
    while(tenSach != "0");

    dsTacGia.push_back(new TacGia(maTacGia, hoTen, dsSachMoi));
    for(int i = n; i < dsSach.size(); i++){
        dsSach[i]->themTacGia(dsTacGia[dsTacGia.size() - 1]);
    }
}

void XoaTacGia::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia){
    string maTacGiaCanXoa; 
    cin.ignore();
    cout << "Nhap ma tac gia: ";
    getline(cin, maTacGiaCanXoa);
    for(int i = 0; i < dsTacGia.size(); i++){
        if(maTacGiaCanXoa == dsTacGia[i]->getMaTacGia()){
            vector<Sach*> v = dsTacGia[i]->getdsSach();
            for(auto &it : v){
                vector<TacGia*> v2 = it->getDsTacGia();
                for(int j = 0; j < v2.size(); j++){
                    if(maTacGiaCanXoa == v2[i]->getMaTacGia()){
                        v2.erase(v2.begin() + i);
                        break; 
                    }
                }
            }
            dsTacGia.erase(dsTacGia.begin()+ i);
            cout << "Xoa thanh cong\n";
            return; 
        }
    }
    cout << "Xoa khong thanh cong\n";
}

void ChinhSuaTacGia::thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia){
    string maTacGiaCanChinhSua; 
    cin.ignore();
    getline(cin, maTacGiaCanChinhSua);
    for(int i = 0; i < dsTacGia.size(); i++){
        if(maTacGiaCanChinhSua == dsTacGia[i]->getMaTacGia()){
            cout << "Nhap ten tac gia moi:";
            string tenTacGiaMoi; 
            getline(cin, tenTacGiaMoi);
            dsTacGia[i]->setHoTen(tenTacGiaMoi);
        }
    }
}

void TacGiaRemoteControl::setCommand(QuanLyTacGia* caulenh){
    this->caulenh = caulenh; 
}

void TacGiaRemoteControl::pressButton(vector<Sach*> dsSach, vector<TacGia*> dsTacGia){
    if(caulenh){
        caulenh->thucThi(dsSach, dsTacGia);
    }
}
#Nguoi dung thong thuong 
username: 23127194
pass: 123

#Quan tri vien
username: 23clc06
pass: 456
#ifndef THANHTOAN_H
#define THANHTOAN_H
#include "header.h"
#include "sach.h"
#include "tacgia.h"
#include "donhang.h"
#include "khachhang.h"
#include "trangthaidonhang.h"
#include "quanlysach.h"
#include "quanlytacgia.h"
#include "quanlydonhang.h"

class  ThanhToan {
public:
	virtual void layPhuongThuc() = 0;
	virtual bool xuLyThanhToan(float amount) = 0;
	virtual ~ThanhToan() {}
};

class TheTinDung : public ThanhToan {
	string cardNumber;
	string expiryDate;
	string cvv;
public:
	void layPhuongThuc() override {
		cout << "Nhap so the: ";
		cin >> cardNumber;
		cout << "Nhap ngay het han (MM/YY): ";
		cin >> expiryDate;
		cout << "Nhap ma CVV: ";
		cin >> cvv;
		cin.ignore();
	}

	bool xuLyThanhToan(float amount) override {
		cout << "\n> [Xu ly thanh toan] \n\n";
		cout << "\tSo tien thanh toan: " << amount << " VND\n";
		// Xu ly thanh toan ...
		return true; // Gia su thanh cong
	}
};

class ChuyenKhoan : public ThanhToan {
public:
	void layPhuongThuc() override {
		cout << "-----------Nha sach OO------------\n";
		cout << "So tai khoan: 68686868\n";
		cout << "Ngan hang: Techcombank\n";
		cout << "Vui long chuyen khoan va xac nhan!\n";
	}

	bool xuLyThanhToan(float amount) override {
		cout << "\n> [Xu ly thanh toan] \n\n";
		cout << "\tSo tien thanh toan: " << amount << " VND\n";
		// ...
		return true; // Gia su thanh cong
	}
};

class ViDienTu : public ThanhToan {
public:
	void layPhuongThuc() override {
		cout << "\nHien thi ma QR (Momo, ZaloPay,...):\n";
		cout << "\n\t[Ma QR da hien thi]\n";
	}

	bool xuLyThanhToan(float amount) override {
		cout << "\n> [Xu ly thanh toan] \n\n";
		cout << "\tSo tien thanh toan: " << amount << " VND\n";
		return true; // Gia su thanh cong
	}
};

class COD : public ThanhToan {
public:
	void layPhuongThuc() override {
		cout << "\nBan se thanh toan tien mat khi lay don hang.\n\n";
	}

	bool xuLyThanhToan(float amount) override {
		cout << "\tSo tien mat thanh toan: " << amount << " VND\n";
		return true; 
	}
};

class BoiCanhThanhToan {
private:
	ThanhToan* strategy;

public:
	BoiCanhThanhToan(ThanhToan* strategy) : strategy(strategy) {}
	void setStrategy(ThanhToan* newStrategy) {
		strategy = newStrategy;
	}
	bool xuLyThanhToan(float amount) {
		strategy->layPhuongThuc();
		return strategy->xuLyThanhToan(amount);
	}
};

#endif
#ifndef HETHONGQUANLY_H
#define HETHONGQUANLY_H
#include "header.h"
#include "sach.h"
#include "tacgia.h"
#include "donhang.h"
#include "khachhang.h"
#include "trangthaidonhang.h"
#include "quanlysach.h"
#include "quanlytacgia.h"
#include "quanlydonhang.h"
#include "thanhtoan.h"
#include "taikhoan.h"

class HeThongQuanLy {
private: 
	static HeThongQuanLy* hethong;
    HeThongQuanLy()
    {

    }
protected: 
	vector<Sach*> dsSach;
	vector<TacGia*> dsTacGia;
	vector<DonHang*> dsDonHang;
	vector<KhachHang*> dsKhachHang;
	vector<TaiKhoan*> dsTaiKhoan; 
public:
	static HeThongQuanLy* getHeThong();
    static void delHeThong();
    ~HeThongQuanLy();
    
	// Quan tri vien: 
	//Doc thong tin tu file 
	Sach* tachThongTinSach(string line_info);
	TacGia* tachThongTinTacGia(string line_info);
	DonHang* tachThongTinDonHang(string line_info);
	KhachHang* tachThongTinKhachHang(string line_info);
	TaiKhoan* tachThongTinTaiKhoan(string line_info); 
	void docThongTinSachTuFile(string file_name);
	void docThongTinTacGiaTuFile(string file_name);
	void docThongTinDonHangTuFile(string file_name);
	void docThongTinKhachHangTuFile(string file_name);
	void docThongTinTaiKhoanTuFile(string file_name);
	void xulyFile();
	//2.1
	void quanLySach();
	void quanLyTacGia();
	void quanLyDonHang();
	void hienThiDSSach();
	void hienThiDSTacGia();
	void hienThiDSKhachHang();
	void hienThiDSDonHang();
	void thongKeDoanhThu(string ngayThongKe);
	void thongKeSoLuongSach();
	void thongKeSoLuongKhachHang();
	// Nguoi dung thong thuong
	//2.2
	void timKiem();
	//2.3
	void xemChiTietSach(string maSach);
	//2.4 
	void datHang();
	//2.5
	void thanhToan();
	//2.6
	void quanLyDonHangDaDat(string maKhachHang);
	//2.7
	void quanLyTaiKhoan(string maKhachHang);
};

#endif
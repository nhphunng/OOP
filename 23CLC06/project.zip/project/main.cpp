﻿#include "header.h"
#include "donhang.h"
#include "hethongquanly.h"
#include "khachhang.h"
#include "quanlysach.h"
#include "sach.h"
#include "tacgia.h"
#include "trangthaidonhang.h"
#include "nguoidung.h"
HeThongQuanLy* HeThongQuanLy::hethong = NULL;


void loading() {
    int count = 3;
    while (count > 0) {
        system("cls");
        cout << "\t Loading" << endl;
        cout << "\t   " << count--;
        sleep_for(seconds(1));
    }
	system("cls");
}
void loading(int count) {
    while (count > 0) {
        system("cls");
        cout << "\t Loading" << endl;
        cout << "\t   " << count--;
        sleep_for(seconds(1));
    }
	system("cls");
}
string dangNhap() {
	string username, password;
	cout << "> Dang nhap tai khoan: " << endl;
	cout << "\t> Username: "; getline(cin, username);
	cout << "\t> Password: "; getline(cin, password);

	// thay doi username nguoi dung & admin
	if (username == "23127194") {
		cout << "Dang nhap thanh cong!!!";
		sleep_for(milliseconds(500));
		return "User";
	}
	else if (username == "23clc06") {
		cout << "Dang nhap thanh cong!!!";
		sleep_for(milliseconds(500));
		return "Admin";
	}
	else {
		cout << "Tai khoan khong ton tai." << endl;
		cout << "Vui long check lai file \"readme.txt\"";
		exit(1);
	}
}
void Menu_QuanTriVien(HeThongQuanLy* nhaSachOO, NguoiDungProxy user){
	while (1) {
	tt:		
		loading();
		cout << "> quan-ly-he-thong" << endl;
		cout << "> Chon chuc nang: " << endl;
		cout << "> 1. Quan ly sach" << endl;
		cout << "> 2. Quan ly tac gia" << endl;
		cout << "> 3. Quan ly don hang" << endl;
		cout << "> 4. Bao cao thong ke" << endl;
		cout << "> 5. Doc thong tin tu file" << endl;
		cout << "> 6. Thoat" << endl;
		cout << "Chon (1-6): ";

		int choice;
		cin >> choice;

		switch (choice)
		{
		case 1:
		{
			
			user.quanLySach(nhaSachOO);
			cout << "\n> An phim bat ki de tiep tuc." << endl;
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			goto tt;
		}
		case 2:
		{
			
			
			user.quanLyTacGia(nhaSachOO);
			cout << "\n> An phim bat ki de tiep tuc." << endl;
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			goto tt;
		}
		case 3:
		{
			
			user.quanLyDonHang(nhaSachOO);
			cout << "\n> An phim bat ki de tiep tuc." << endl;
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			goto tt;
		}
		case 4:
		{
			while (1) {
				system("cls");
				cout << "\n>  Nhap tieu chi: ";
				cout << "\n> 1. Thong ke doanh thu";
				cout << "\n> 2. Thong ke so luong sach";
				cout << "\n> 3. Thong ke so luong khach hang";
				cout << "\n> 4. Quay lai.";
				cout << "\n> Chon (1-4): ";

				int choose;
				cin >> choose;
				cin.ignore();

				switch (choose)
				{
				case 1:
				{
					string ngayThongKe;
					cout << "Nhap ngay thong ke: ";
					getline(cin, ngayThongKe);
					user.thongKeDoanhThu(nhaSachOO, ngayThongKe);
					break;
				}
				case 2:
				{
					user.thongKeSoLuongSach(nhaSachOO);
					break;
				}
				case 3:
				{
					user.thongKeSoLuongKhachHang(nhaSachOO);
					break;
				}
				default:
					goto tt;
					break;
				}
				cout << "\n> Nhan Enter de tiep tuc.";
				string Enter;
				getline(cin, Enter);
			}
		}
		case 5:
		{
			system("cls");
			user.xulyFile(nhaSachOO);
			cout << "\n\tDang doc file ...";
			sleep_for(seconds(1));
			system("cls");
			cout << "\n\t Doc file thanh cong.";
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		default:
			exit(1);
		}
	}
}
void Menu_NguoiDungThongThuong(HeThongQuanLy* nhaSachOO, NguoiDungProxy user){
	while (1) {
		loading(3);
		cout << "> danh-muc-nguoi-dung" << endl;
		cout << "> chon chuc nang: " << endl;
		cout << "> 1. Tim kiem sach" << endl;
		cout << "> 2. Hien thi thong tin chi tiet sach" << endl;
		cout << "> 3. Dat hang" << endl;
		cout << "> 4. Thanh toan" << endl;
		cout << "> 5. Quan ly don hang" << endl;
		cout << "> 6. Quan ly tai khoan" << endl;
		cout << "> 7. Thoat" << endl;
		cout << "chon (1-7): ";

		int choice;
		cin >> choice;
		cin.ignore();
		cout << endl;

		switch (choice)
		{
		case 1:
		{
			user.timKiem(nhaSachOO);
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 2:
		{
			string maSach;
			cout << "\n> Nhap ma sach: ";
			getline(cin, maSach);
			user.xemChiTietSach(nhaSachOO, maSach);
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 3:
		{
			user.datHang(nhaSachOO);
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 4:
		{
			user.thanhToan(nhaSachOO);
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 5:
		{
			string  maKhachHang;
			cout << "\n> Nhap ma khach hang: ";
			getline(cin, maKhachHang);
			user.quanLyDonHangDaDat(nhaSachOO, maKhachHang);
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		case 6:
		{
			string  maKhachHang;
			cout << "\n> Nhap ma khach hang: ";
			getline(cin, maKhachHang);
			user.quanLyTaiKhoan(nhaSachOO, maKhachHang);
			cout << "\n> Nhan Enter de tiep tuc.";
			string Enter;
			getline(cin, Enter);
			break;
		}
		default:
			exit(1);
		}
	}
}

int main() {
	// 	#Nguoi dung thong thuong 
	// username: 23127194
	// pass: 123

	// #Quan tri vien
	// username: 23clc06
	// pass: 456
    HeThongQuanLy* nhaSachOO = HeThongQuanLy::getHeThong();
	string role = dangNhap();
	//Tu dong nhap file;
	nhaSachOO->xulyFile();
    
	//Cap vai tro cho user dua tren thong tin dang nhap
	NguoiDungProxy user(role);

	//Kiem tra role va chay he thong
	if (role == "Admin") Menu_QuanTriVien(nhaSachOO, user);
	else if (role == "User") Menu_NguoiDungThongThuong(nhaSachOO, user);
    return 0; 
}
#ifndef QUANLYSACH_H
#define QUANLYSACH_H
#include "header.h"
#include "sach.h"
#include "tacgia.h"
#include "donhang.h"
#include "khachhang.h"
#include "trangthaidonhang.h"

class QuanLySach{
    public: 
        virtual void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia) = 0;
        virtual ~QuanLySach(){}
};

class ThemSach : public QuanLySach{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};

class XoaSach : public QuanLySach{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};

class ChinhSuaSach : public QuanLySach{
    public: 
        void thucThi(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};

class RemoteControl{
    QuanLySach *caulenh; 
    public: 
    void setCommand(QuanLySach* caulenh);
    void pressButton(vector<Sach*> dsSach, vector<TacGia*> dsTacGia);
};

#endif
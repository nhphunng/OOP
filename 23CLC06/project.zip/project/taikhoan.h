#include "header.h"
#include "khachhang.h"

class TaiKhoan{
	private: 
		string maKhachHang;
		string matKhau; 
	public: 
		TaiKhoan();
		TaiKhoan(string maKhachHang, string matkhau);
        void setMatKhau(string matKhauMoi);
		string getMaKhachHang();
		bool dangnhap();
		~TaiKhoan();
};

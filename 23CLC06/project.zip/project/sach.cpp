#include "sach.h"
Sach::Sach(){
	maSach = "";
	tenSach = "";
	theLoai = "";
	namXuatBan = "";
	nhaXuatBan = "";
	giaBan = 0; 
	soLuongTonKho = 0; 
}
Sach::Sach(string tenSach){
	maSach = "";
	this->tenSach = tenSach; 
	theLoai = "";
	namXuatBan = "";
	nhaXuatBan = "";
	giaBan = 0; 
	soLuongTonKho = 0; 
}
Sach::Sach(string maSach, string tenSach, string theLoai, string namXuatBan, string nhaXuatBan, double giaBan, int soLuongTonKho, vector<TacGia*> dsTacGia){
	this->maSach = maSach;  
	this->tenSach = tenSach; 
	this->theLoai = theLoai; 
	this->nhaXuatBan = nhaXuatBan;
	this->namXuatBan = namXuatBan; 
	this->giaBan = giaBan; 
	this->soLuongTonKho = soLuongTonKho; 
	for(int i = 0; i < dsTacGia.size(); i++){
		this->dsTacGia.push_back(dsTacGia[i]);
	}
	
}
string Sach::getMaSach() {
	return this->maSach;
}
string Sach::getTenSach() {
	return this->tenSach;
}
string Sach::getTheLoai() {
	return this->theLoai;
}
string Sach::getNamXuatBan() {
	return this->namXuatBan;
}
string Sach::getNhaXuatBan() {
	return this->nhaXuatBan;
}
double Sach::getGiaBan() {
	return this->giaBan;
}
int Sach::getSoLuongTonKho() {
	return this->soLuongTonKho;
}
vector<TacGia*> Sach::getDsTacGia() {
	return this->dsTacGia;
}
void Sach::setMaSach(string maSachMoi) {
	this->maSach = maSachMoi;
}
void Sach::setTenSach(string tenSachMoi) {
	this->tenSach = tenSachMoi;
}
void Sach::setTheLoai(string theLoaiMoi) {
	this->theLoai = theLoaiMoi;
}
void Sach::setNamXuatBan(string namXuatBanMoi) {
	this->namXuatBan = namXuatBanMoi;
}
void Sach::setNhaXuatBan(string nhaXuatBanMoi) {
	this->nhaXuatBan = nhaXuatBanMoi;
}
void Sach::setGiaBan(double giaBanMoi) {
	this->giaBan = giaBanMoi;
}
void Sach::setSoLuongTonKho(int soLuongTonKhoMoi) {
	this->soLuongTonKho = soLuongTonKhoMoi;
}
void Sach::setDsTacGia(vector<TacGia*> dsTacGiaMoi) {
	for (auto &it : dsTacGia) delete it;
	dsTacGia.clear();
	this->dsTacGia = dsTacGiaMoi;
}
void Sach::hienthiSach(){
	cout << "Thong tin chi tiet sach " << this->getMaSach() << endl; 
	cout << "Ten sach: " << this->getTenSach() << endl; 
	cout << "Tac gia: ";
	for (size_t i = 0; i < dsTacGia.size(); ++i) {
	cout << dsTacGia[i]->getHoTen();
	if (i < dsTacGia.size() - 1) cout << " ";
	}
	cout << endl; 
	cout << "The loai: " << this->getTheLoai() << endl; 
	cout << "Nam xuat ban: " << this->getNamXuatBan() << endl; 
	cout << "Nha xuat ban: " << this->getNhaXuatBan() << endl; 
	cout << "Gia ban: " << this->getGiaBan() << endl; 
	cout << "So luong ton kho: " << this->getSoLuongTonKho() << endl; 
	cout << endl; 
}
void Sach::themTacGia(TacGia* tacgia){
	dsTacGia.push_back(tacgia);
}


//SachCoMoTa
SachCoMoTa::SachCoMoTa(string maSach, string tenSach, string theLoai, string namXuatBan, string nhaXuatBan, double giaBan, int soLuongTonKho, vector<TacGia*> dsTacGia, string mota) : Sach(maSach, tenSach, theLoai, namXuatBan, nhaXuatBan, giaBan, soLuongTonKho, dsTacGia), moTa(mota){}

void SachCoMoTa::hienthiSach(){
	cout << "Thong tin chi tiet sach " << this->getMaSach() << endl; 
	cout << "Ten sach: " << this->getTenSach() << endl; 
	cout << "Tac gia: ";
	vector<TacGia*> dsTacGia = this->getDsTacGia();
	for (size_t i = 0; i < dsTacGia.size(); ++i) {
	cout << dsTacGia[i]->getHoTen();
	if (i < dsTacGia.size() - 1) cout << " ";
	}
	cout << endl; 
	cout << "The loai: " << this->getTheLoai() << endl; 
	cout << "Nam xuat ban: " << this->getNamXuatBan() << endl; 
	cout << "Nha xuat ban: " << this->getNhaXuatBan() << endl; 
	cout << "Gia ban: " << this->getGiaBan() << endl; 
	cout << "So luong ton kho: " << this->getSoLuongTonKho() << endl; 
	cout << "Mo ta: " << this->moTa; 
	cout << endl; 
}
Sach::Sach(const Sach &other){
	this->maSach = other.maSach; 
	this->tenSach = other.tenSach; 
	this->theLoai = other.theLoai; 
	this->namXuatBan = other.namXuatBan; 
	this->nhaXuatBan = other.nhaXuatBan; 
	this->giaBan = other.giaBan; 
	this->soLuongTonKho = other.soLuongTonKho; 
	for(int i = 0; i < dsTacGia.size(); i++){
		this->dsTacGia.push_back(other.dsTacGia[i]);
	}
}
Sach::~Sach(){
	if(!dsTacGia.empty())
		for(auto &it : dsTacGia){
			delete it; 
		}
	dsTacGia.clear();
}